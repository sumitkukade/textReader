function test()
{
		var button = document.getElementById('continue-button');
		button.form.submit();
}
